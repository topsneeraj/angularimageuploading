import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadimagComponent } from './uploadimag.component';

describe('UploadimagComponent', () => {
  let component: UploadimagComponent;
  let fixture: ComponentFixture<UploadimagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadimagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadimagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
