import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,NgForm} from '@angular/forms';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { ListdataComponent } from './listdata/listdata.component';
import{RouterModule,Routes} from '@angular/router';
import{EditlistComponent} from './editlist/editlist.component';
import { UploadimagComponent } from './uploadimag/uploadimag.component';

const app:Routes = [{path:"edit",component:EditlistComponent},{path:"listdata",component:ListdataComponent},{path:'',component:ListdataComponent}];

@NgModule({
  declarations: [
    AppComponent,
    EditlistComponent,
    ListdataComponent,
    UploadimagComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(app)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
