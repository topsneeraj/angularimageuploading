import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo';

   constructor(private app:HttpClient)
   {
     


   }
  addstudent(fromval)
  {
   var emp_name = fromval.value.empname;
   var emp_add = fromval.value.empadd;
   var emp_mob = fromval.value.empmob;

   var obj = {"emp_name":emp_name,"emp_add":emp_add,"emp_mob":emp_mob};


      this.app.post("http://localhost/angular/indeximage.php",obj).subscribe(res=>{

         console.log("ok");
         

      })

  }
}
